package com.elysium.crack;

import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class LockReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_SCREEN_ON.equals(action) || Intent.ACTION_USER_PRESENT.equals(action)) {
            boolean isKioskRunning = context.getSharedPreferences("kiosk", Context.MODE_PRIVATE).getBoolean("is_running", false);
            if (isKioskRunning) {
                DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                ComponentName admin = new ComponentName(context, AdminReceiver.class);
                if (dpm != null && dpm.isAdminActive(admin)) {
                    // Блокируем экран обратно
                    dpm.lockNow();
                }
            }
        }
    }
}