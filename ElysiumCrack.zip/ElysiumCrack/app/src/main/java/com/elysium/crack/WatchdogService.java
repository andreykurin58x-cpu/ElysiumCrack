package com.elysium.crack;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class WatchdogService extends Service {
    private Handler handler;
    private Runnable runnable;
    private static final long CHECK_INTERVAL = 2000; // Было 300, стало 2000

    @Override
    public void onCreate() {
        super.onCreate();
        String channelId = "watchdog";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, "watchdog", NotificationManager.IMPORTANCE_MIN);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? 
            new Notification.Builder(this, channelId) : 
            new Notification.Builder(this);
        Notification n = b.setContentTitle("ElysiumCrack")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build();
        startForeground(2, n);

        handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            public void run() {
                if (KioskActivity.isKioskAlive) {
                    try {
                        android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                        java.util.List<android.app.ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
                        if (!tasks.isEmpty()) {
                            String topActivity = tasks.get(0).topActivity.getClassName();
                            // Запускаем ТОЛЬКО если мы НЕ наверху
                            if (!topActivity.equals(KioskActivity.class.getName())) {
                                Intent i = new Intent(WatchdogService.this, KioskActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | 
                                           Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | 
                                           Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                startActivity(i);
                            }
                        }
                    } catch (Throwable ignored) {}
                }
                handler.postDelayed(this, CHECK_INTERVAL);
            }
        };
        handler.post(runnable);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { 
        return START_STICKY; 
    }
    
    @Override
    public IBinder onBind(Intent intent) { return null; }
    
    @Override
    public void onDestroy() {
        if (handler != null) handler.removeCallbacks(runnable);
        super.onDestroy();
    }
}