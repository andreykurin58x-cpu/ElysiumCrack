private void requestAllPermissions() {
    if (!Settings.canDrawOverlays(this)) {
        Toast.makeText(this, "Выдай разрешение Overlay", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        return;
    }

    DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
    if (!dpm.isAdminActive(componentName())) {
        Toast.makeText(this, "Активируй Администратора", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName());
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Для инжекта чита");
        startActivity(i);
        return;
    }

    // ПРОВЕРКА ACCESSIBILITY
    if (!isAccessibilityServiceEnabled()) {
        Toast.makeText(this, "Включи Службу специальных возможностей для защиты", Toast.LENGTH_LONG).show();
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        return;
    }

    if (Build.VERSION.SDK_INT >= 33) {
        if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Дай разрешение на уведомления", Toast.LENGTH_SHORT).show();
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
    }

    showMainMenu();
}

// Метод проверки, включена ли служба
private boolean isAccessibilityServiceEnabled() {
    String prefString = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
    return prefString != null && prefString.contains(getPackageName() + "/" + KioskAccessibilityService.class.getName());
}
