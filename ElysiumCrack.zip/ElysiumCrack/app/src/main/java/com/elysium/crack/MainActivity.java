package com.elysium.crack;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_NOTIF = 100;
    private Button btnOverlay, btnAdmin, btnNotif, btnStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(40, 80, 40, 40);

        TextView info = new TextView(this);
        info.setText("Выдай все разрешения. Как только все — киоск запустится сам.");
        info.setTextSize(16);
        ll.addView(info);

        btnOverlay = new Button(this);
        btnOverlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        ll.addView(btnOverlay);

        btnAdmin = new Button(this);
        btnAdmin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                DevicePolicyManager dpm =
                        (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                if (!dpm.isAdminActive(componentName())) {
                    Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName());
                    i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "ElysiumCrack");
                    startActivity(i);
                }
            }
        });
        ll.addView(btnAdmin);

        btnNotif = new Button(this);
        btnNotif.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(
                            new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                            REQ_NOTIF);
                }
            }
        });
        ll.addView(btnNotif);

        btnStart = new Button(this);
        btnStart.setText("Запустить киоск");
        btnStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                launchKiosk();
            }
        });
        ll.addView(btnStart);

        setContentView(ll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private void refreshState() {
        boolean overlay = Settings.canDrawOverlays(this);

        DevicePolicyManager dpm =
                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        boolean admin = dpm.isAdminActive(componentName());

        boolean notif = true;
        if (Build.VERSION.SDK_INT >= 33) {
            notif = checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }

        btnOverlay.setText((overlay ? "✓ " : "1. ") + "Overlay поверх приложений");
        btnAdmin.setText((admin ? "✓ " : "2. ") + "Администратор устройства");
        btnNotif.setText((notif ? "✓ " : "3. ") + "Уведомления");

        if (overlay && admin && notif) {
            launchKiosk();
        }
    }

    private void launchKiosk() {
        startActivity(new Intent(this, KioskActivity.class));
        finish();
    }

    private ComponentName componentName() {
        return new ComponentName(this, AdminReceiver.class);
    }
}
