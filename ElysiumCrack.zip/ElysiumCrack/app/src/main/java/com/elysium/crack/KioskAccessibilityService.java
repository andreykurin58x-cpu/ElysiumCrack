package com.elysium.crack;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

public class KioskAccessibilityService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence packageName = event.getPackageName();
            if (packageName != null) {
                String pkg = packageName.toString();
                boolean isKioskRunning = getSharedPreferences("kiosk", MODE_PRIVATE).getBoolean("is_running", false);
                
                if (!isKioskRunning) return;

                // Если открылось что-то не наше (рабочий стол, настройки, шторка) — выкидываем обратно
                if (!pkg.equals("com.elysium.crack")) {
                    Intent i = new Intent(this, KioskActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                }
            }
        }
    }

    @Override
    public void onInterrupt() {}
}