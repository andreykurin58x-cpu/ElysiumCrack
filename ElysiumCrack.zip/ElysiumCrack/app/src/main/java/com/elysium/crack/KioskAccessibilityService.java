package com.elysium.crack;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

public class KioskAccessibilityService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence packageName = event.getPackageName();
            if (packageName != null) {
                String pkg = packageName.toString();
                
                boolean isKioskRunning = getSharedPreferences("kiosk", MODE_PRIVATE).getBoolean("is_running", false);
                
                if (!isKioskRunning) return;

                // Если открывается рабочий стол, настройки, обзор или системный интерфейс
                if (pkg.equals("com.android.settings") || 
                    pkg.contains("launcher") || 
                    pkg.contains("recents") ||
                    pkg.contains("systemui") ||
                    pkg.contains("iqoo") ||
                    pkg.contains("vivo")) {
                    
                    // Блокируем экран админом
                    try {
                        android.app.admin.DevicePolicyManager dpm = (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                        android.content.ComponentName admin = new android.content.ComponentName(this, AdminReceiver.class);
                        if (dpm != null && dpm.isAdminActive(admin)) {
                            dpm.lockNow();
                        }
                    } catch (Throwable ignored) {}

                    Intent i = new Intent(this, KioskActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                }
            }
        }
    }

    @Override
    public void onInterrupt() {}
}