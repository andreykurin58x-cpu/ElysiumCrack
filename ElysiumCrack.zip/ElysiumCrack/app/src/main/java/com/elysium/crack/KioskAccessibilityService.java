package com.elysium.crack;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class KioskAccessibilityService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence packageName = event.getPackageName();
            if (packageName != null) {
                String pkg = packageName.toString();
                
                // Если открываются настройки, рабочий стол или список приложений — возвращаем киоск
                if (pkg.equals("com.android.settings") || 
                    pkg.contains("launcher") || 
                    pkg.contains("systemui") ||
                    pkg.contains("iqoo") ||
                    pkg.contains("vivo")) {
                    
                    Intent i = new Intent(this, KioskActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
    }
}