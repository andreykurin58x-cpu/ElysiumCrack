package com.elysium.crack;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class KioskAccessibilityService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence packageName = event.getPackageName();
            if (packageName != null) {
                String pkg = packageName.toString();
                boolean isKioskRunning = getSharedPreferences("kiosk", MODE_PRIVATE).getBoolean("is_running", false);
                
                if (!isKioskRunning) return;

                // Если открылось что-то не наше — моментально возвращаем киоск
                if (!pkg.equals("com.elysium.crack")) {
                    Intent i = new Intent(this, KioskActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                }
            }
        }
        
        // Дополнительно: блокируем нажатия на системные кнопки (Home, Recents)
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            AccessibilityNodeInfo source = event.getSource();
            if (source != null) {
                CharSequence text = source.getText();
                CharSequence desc = source.getContentDescription();
                if ((text != null && text.toString().contains("Домой")) || 
                    (desc != null && desc.toString().contains("Домой"))) {
                    // Просто игнорируем клик
                }
            }
        }
    }

    @Override
    public void onInterrupt() {}
}